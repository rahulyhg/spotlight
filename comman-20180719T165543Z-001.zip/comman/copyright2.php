<section class="page_copyright ds section_padding_top_30 section_padding_bottom_10">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 text-center">
							<a href="index-2.html" class="logo logo_image vertical_logo grey">
								<h1>models
									<span class="muellerhoff">Agency</span>
								</h1>
								<img src="images/logo.png" alt="">
							</a>
						</div>
						<div class="col-sm-12 text-center">
							<p>Copyright 2016. Solar by
								<a href="http://modernwebtemplates.com/">MWTemplates</a>
							</p>
						</div>
					</div>
				</div>
			</section>